#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <netinet/in.h>
#include <string.h>

#define LINE 10

int main()
{
	//create socket for server and check if created properly, else exit program
	if(int serverSocket = socket(AF_INET, SOCK_STREAM, 0) < 0)
	{
		printf("Error: failed to create socket");
		return 1;
	}

	//configure server address struct
	struct sockaddr_in serverAddress;
	serverAddress.sin_family = AF_INET;
	serverAddress.sin_port = htons(80);
	serverAddress.sin_addr.s_addr = htonl(INADDR_ANY);

	//bind socket to server address
	if(bind(serverSocket, (struct sockaddr *) &serverAddress, sizeof(serverAddress)) < 0)
	{
		printf("Error: failed to bind");
		return 1;
	}

	//set server to listen
	if(listen(serverSocket, LINE) < 0)
	{
		printf("Error: failed to listen");
		return 1;
	}

	//wait for a connection 
	int clientSocket;
	
	while(1)
	{
		if(clientSocket = accept(serverSocket, NULL, NULL) < 0)
		{
			printf("Error: failed to accept client socket");
		}
		else
		{
			send(clientSocket, message, sizeof(message), 0);
			close(clientSocket); 
		}
	}

	return 0;
}
